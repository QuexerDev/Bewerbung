# BackendBanFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create4**](BackendBanFacadeApi.md#create4) | **POST** /ban/create | 
[**deleteBan**](BackendBanFacadeApi.md#deleteBan) | **DELETE** /ban/delete | 
[**getActiveBan**](BackendBanFacadeApi.md#getActiveBan) | **GET** /ban/getActiveBan/{uuid} | 
[**getActiveMute**](BackendBanFacadeApi.md#getActiveMute) | **GET** /ban/getActiveMute/{uuid} | 
[**getBanHistory**](BackendBanFacadeApi.md#getBanHistory) | **GET** /ban/getBanHistory/{uuid} | 
[**getMadeBans**](BackendBanFacadeApi.md#getMadeBans) | **GET** /ban/getMadeBans/{uuid} | 
[**updateBan**](BackendBanFacadeApi.md#updateBan) | **PATCH** /ban/update/{id} | 

<a name="create4"></a>
# **create4**
> BackendBan create4(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
BackendBan body = new BackendBan(); // BackendBan | 
try {
    BackendBan result = apiInstance.create4(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#create4");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendBan**](BackendBan.md)|  |

### Return type

[**BackendBan**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="deleteBan"></a>
# **deleteBan**
> deleteBan(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
BackendBan body = new BackendBan(); // BackendBan | 
try {
    apiInstance.deleteBan(body);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#deleteBan");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendBan**](BackendBan.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="getActiveBan"></a>
# **getActiveBan**
> BackendBan getActiveBan(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    BackendBan result = apiInstance.getActiveBan(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#getActiveBan");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**BackendBan**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getActiveMute"></a>
# **getActiveMute**
> BackendBan getActiveMute(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    BackendBan result = apiInstance.getActiveMute(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#getActiveMute");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**BackendBan**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getBanHistory"></a>
# **getBanHistory**
> List&lt;BackendBan&gt; getBanHistory(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    List<BackendBan> result = apiInstance.getBanHistory(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#getBanHistory");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**List&lt;BackendBan&gt;**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getMadeBans"></a>
# **getMadeBans**
> List&lt;BackendBan&gt; getMadeBans(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    List<BackendBan> result = apiInstance.getMadeBans(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#getMadeBans");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**List&lt;BackendBan&gt;**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="updateBan"></a>
# **updateBan**
> BackendBan updateBan(body, id)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendBanFacadeApi;


BackendBanFacadeApi apiInstance = new BackendBanFacadeApi();
BackendBan body = new BackendBan(); // BackendBan | 
Integer id = 56; // Integer | 
try {
    BackendBan result = apiInstance.updateBan(body, id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendBanFacadeApi#updateBan");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendBan**](BackendBan.md)|  |
 **id** | **Integer**|  |

### Return type

[**BackendBan**](BackendBan.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

