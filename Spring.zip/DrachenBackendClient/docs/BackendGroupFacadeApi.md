# BackendGroupFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create2**](BackendGroupFacadeApi.md#create2) | **POST** /group/create | 
[**delete2**](BackendGroupFacadeApi.md#delete2) | **DELETE** /group/delete | 
[**getAll**](BackendGroupFacadeApi.md#getAll) | **GET** /group/getAll | 
[**getAllById**](BackendGroupFacadeApi.md#getAllById) | **GET** /group/getPlayersInGroup/{id} | 
[**update2**](BackendGroupFacadeApi.md#update2) | **PATCH** /group/update | 

<a name="create2"></a>
# **create2**
> BackendGroup create2(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendGroupFacadeApi;


BackendGroupFacadeApi apiInstance = new BackendGroupFacadeApi();
BackendGroup body = new BackendGroup(); // BackendGroup | 
try {
    BackendGroup result = apiInstance.create2(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendGroupFacadeApi#create2");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendGroup**](BackendGroup.md)|  |

### Return type

[**BackendGroup**](BackendGroup.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="delete2"></a>
# **delete2**
> delete2(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendGroupFacadeApi;


BackendGroupFacadeApi apiInstance = new BackendGroupFacadeApi();
BackendGroup body = new BackendGroup(); // BackendGroup | 
try {
    apiInstance.delete2(body);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendGroupFacadeApi#delete2");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendGroup**](BackendGroup.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="getAll"></a>
# **getAll**
> List&lt;BackendGroup&gt; getAll()



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendGroupFacadeApi;


BackendGroupFacadeApi apiInstance = new BackendGroupFacadeApi();
try {
    List<BackendGroup> result = apiInstance.getAll();
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendGroupFacadeApi#getAll");
    e.printStackTrace();
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**List&lt;BackendGroup&gt;**](BackendGroup.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getAllById"></a>
# **getAllById**
> List&lt;DrachenPlayer&gt; getAllById(id)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendGroupFacadeApi;


BackendGroupFacadeApi apiInstance = new BackendGroupFacadeApi();
Long id = 789L; // Long | 
try {
    List<DrachenPlayer> result = apiInstance.getAllById(id);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendGroupFacadeApi#getAllById");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **id** | **Long**|  |

### Return type

[**List&lt;DrachenPlayer&gt;**](DrachenPlayer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="update2"></a>
# **update2**
> BackendGroup update2(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendGroupFacadeApi;


BackendGroupFacadeApi apiInstance = new BackendGroupFacadeApi();
BackendGroup body = new BackendGroup(); // BackendGroup | 
try {
    BackendGroup result = apiInstance.update2(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendGroupFacadeApi#update2");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendGroup**](BackendGroup.md)|  |

### Return type

[**BackendGroup**](BackendGroup.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

