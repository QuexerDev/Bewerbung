# BackendChests

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**common** | **Integer** |  |  [optional]
**uncommon** | **Integer** |  |  [optional]
**rare** | **Integer** |  |  [optional]
**epic** | **Integer** |  |  [optional]
**legendary** | **Integer** |  |  [optional]
**drachenPlayer** | [**DrachenPlayer**](DrachenPlayer.md) |  |  [optional]
