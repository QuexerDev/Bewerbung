# DrachenPlayer

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**uuid** | **String** |  |  [optional]
**name** | **String** |  |  [optional]
**chests** | [**BackendChests**](BackendChests.md) |  |  [optional]
**backendFriendSettings** | [**BackendFriendSettings**](BackendFriendSettings.md) |  |  [optional]
**drachenPlayerData** | [**DrachenPlayerData**](DrachenPlayerData.md) |  |  [optional]
**drachenPlayerDates** | [**DrachenPlayerDates**](DrachenPlayerDates.md) |  |  [optional]
**madeBans** | [**List&lt;BackendBan&gt;**](BackendBan.md) |  |  [optional]
**banPoints** | **Long** |  |  [optional]
**clientPerms** | **List&lt;String&gt;** |  |  [optional]
**data** | [**JSONObject**](JSONObject.md) |  |  [optional]
**groupId** | **Long** |  |  [optional]
**groupExpire** | **Long** |  |  [optional]
