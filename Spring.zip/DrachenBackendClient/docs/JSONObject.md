# JSONObject

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**empty** | **Boolean** |  |  [optional]
