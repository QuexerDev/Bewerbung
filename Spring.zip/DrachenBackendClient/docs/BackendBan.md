# BackendBan

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**uuid** | **String** |  |  [optional]
**punisher** | **String** |  |  [optional]
**banType** | [**BanTypeEnum**](#BanTypeEnum) |  |  [optional]
**reason** | **String** |  |  [optional]
**active** | **Boolean** |  |  [optional]
**punishedAt** | **Long** |  |  [optional]
**punishEnd** | **Long** |  |  [optional]

<a name="BanTypeEnum"></a>
## Enum: BanTypeEnum
Name | Value
---- | -----
CHAT | &quot;CHAT&quot;
BAN | &quot;BAN&quot;
