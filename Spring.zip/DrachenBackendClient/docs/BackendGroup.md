# BackendGroup

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**color** | **String** |  |  [optional]
**prefix** | **String** |  |  [optional]
**inherits** | [**List&lt;BackendGroup&gt;**](BackendGroup.md) |  |  [optional]
**perms** | **List&lt;String&gt;** |  |  [optional]
**fullName** | **String** |  |  [optional]
