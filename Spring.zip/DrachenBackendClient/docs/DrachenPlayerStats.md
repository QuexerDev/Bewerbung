# DrachenPlayerStats

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**mode** | **String** |  |  [optional]
**uuid** | **String** |  |  [optional]
**points** | **Long** |  |  [optional]
**data** | [**JSONObject**](JSONObject.md) |  |  [optional]
