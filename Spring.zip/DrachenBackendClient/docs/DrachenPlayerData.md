# DrachenPlayerData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**drachenPlayer** | [**DrachenPlayer**](DrachenPlayer.md) |  |  [optional]
**mett** | **Long** |  |  [optional]
**ofenkaese** | **Long** |  |  [optional]
**level** | **Long** |  |  [optional]
**xp** | **Long** |  |  [optional]
