# TestFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getTest**](TestFacadeApi.md#getTest) | **GET** /test/getTest/{msg} | 

<a name="getTest"></a>
# **getTest**
> String getTest(msg)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.TestFacadeApi;


TestFacadeApi apiInstance = new TestFacadeApi();
String msg = "msg_example"; // String | 
try {
    String result = apiInstance.getTest(msg);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling TestFacadeApi#getTest");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **msg** | **String**|  |

### Return type

**String**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

