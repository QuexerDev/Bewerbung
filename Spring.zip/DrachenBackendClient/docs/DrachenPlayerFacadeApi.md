# DrachenPlayerFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create1**](DrachenPlayerFacadeApi.md#create1) | **POST** /player/create | 
[**delete1**](DrachenPlayerFacadeApi.md#delete1) | **DELETE** /player/delete | 
[**get**](DrachenPlayerFacadeApi.md#get) | **GET** /player/get/{uuid} | 
[**update1**](DrachenPlayerFacadeApi.md#update1) | **PATCH** /player/update | 

<a name="create1"></a>
# **create1**
> DrachenPlayer create1(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerFacadeApi;


DrachenPlayerFacadeApi apiInstance = new DrachenPlayerFacadeApi();
DrachenPlayer body = new DrachenPlayer(); // DrachenPlayer | 
try {
    DrachenPlayer result = apiInstance.create1(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerFacadeApi#create1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayer**](DrachenPlayer.md)|  |

### Return type

[**DrachenPlayer**](DrachenPlayer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="delete1"></a>
# **delete1**
> delete1(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerFacadeApi;


DrachenPlayerFacadeApi apiInstance = new DrachenPlayerFacadeApi();
DrachenPlayer body = new DrachenPlayer(); // DrachenPlayer | 
try {
    apiInstance.delete1(body);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerFacadeApi#delete1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayer**](DrachenPlayer.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="get"></a>
# **get**
> DrachenPlayer get(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerFacadeApi;


DrachenPlayerFacadeApi apiInstance = new DrachenPlayerFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    DrachenPlayer result = apiInstance.get(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerFacadeApi#get");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**DrachenPlayer**](DrachenPlayer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="update1"></a>
# **update1**
> DrachenPlayer update1(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerFacadeApi;


DrachenPlayerFacadeApi apiInstance = new DrachenPlayerFacadeApi();
DrachenPlayer body = new DrachenPlayer(); // DrachenPlayer | 
try {
    DrachenPlayer result = apiInstance.update1(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerFacadeApi#update1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayer**](DrachenPlayer.md)|  |

### Return type

[**DrachenPlayer**](DrachenPlayer.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

