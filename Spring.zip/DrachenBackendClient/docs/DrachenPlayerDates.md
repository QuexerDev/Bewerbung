# DrachenPlayerDates

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**drachenPlayer** | [**DrachenPlayer**](DrachenPlayer.md) |  |  [optional]
**firstJoined** | **Long** |  |  [optional]
**lastQuit** | **Long** |  |  [optional]
**playTime** | **Long** |  |  [optional]
**lastJoin** | **Long** |  |  [optional]
