# BackendFriendSettings

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Long** |  |  [optional]
**drachenPlayer** | [**DrachenPlayer**](DrachenPlayer.md) |  |  [optional]
**msg** | **Boolean** |  |  [optional]
**request** | **Boolean** |  |  [optional]
**party** | **Boolean** |  |  [optional]
**jump** | **Boolean** |  |  [optional]
