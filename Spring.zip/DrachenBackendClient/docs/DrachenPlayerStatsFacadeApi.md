# DrachenPlayerStatsFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create**](DrachenPlayerStatsFacadeApi.md#create) | **POST** /stats/create | 
[**delete**](DrachenPlayerStatsFacadeApi.md#delete) | **DELETE** /stats/delete | 
[**getAllByUuid**](DrachenPlayerStatsFacadeApi.md#getAllByUuid) | **GET** /stats/get/{uuid} | 
[**getByUuidAndMode**](DrachenPlayerStatsFacadeApi.md#getByUuidAndMode) | **GET** /stats/get/{uuid}/{mode} | 
[**getTop10**](DrachenPlayerStatsFacadeApi.md#getTop10) | **GET** /stats/getTop/{mode} | 
[**update**](DrachenPlayerStatsFacadeApi.md#update) | **PATCH** /stats/update | 

<a name="create"></a>
# **create**
> DrachenPlayerStats create(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
DrachenPlayerStats body = new DrachenPlayerStats(); // DrachenPlayerStats | 
try {
    DrachenPlayerStats result = apiInstance.create(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#create");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayerStats**](DrachenPlayerStats.md)|  |

### Return type

[**DrachenPlayerStats**](DrachenPlayerStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="delete"></a>
# **delete**
> delete(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
DrachenPlayerStats body = new DrachenPlayerStats(); // DrachenPlayerStats | 
try {
    apiInstance.delete(body);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#delete");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayerStats**](DrachenPlayerStats.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="getAllByUuid"></a>
# **getAllByUuid**
> List&lt;DrachenPlayerStats&gt; getAllByUuid(uuid)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
String uuid = "uuid_example"; // String | 
try {
    List<DrachenPlayerStats> result = apiInstance.getAllByUuid(uuid);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#getAllByUuid");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |

### Return type

[**List&lt;DrachenPlayerStats&gt;**](DrachenPlayerStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getByUuidAndMode"></a>
# **getByUuidAndMode**
> DrachenPlayerStats getByUuidAndMode(uuid, mode)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
String uuid = "uuid_example"; // String | 
String mode = "mode_example"; // String | 
try {
    DrachenPlayerStats result = apiInstance.getByUuidAndMode(uuid, mode);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#getByUuidAndMode");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **uuid** | **String**|  |
 **mode** | **String**|  |

### Return type

[**DrachenPlayerStats**](DrachenPlayerStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="getTop10"></a>
# **getTop10**
> List&lt;DrachenPlayerStats&gt; getTop10(mode)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
String mode = "mode_example"; // String | 
try {
    List<DrachenPlayerStats> result = apiInstance.getTop10(mode);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#getTop10");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **mode** | **String**|  |

### Return type

[**List&lt;DrachenPlayerStats&gt;**](DrachenPlayerStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="update"></a>
# **update**
> DrachenPlayerStats update(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.DrachenPlayerStatsFacadeApi;


DrachenPlayerStatsFacadeApi apiInstance = new DrachenPlayerStatsFacadeApi();
DrachenPlayerStats body = new DrachenPlayerStats(); // DrachenPlayerStats | 
try {
    DrachenPlayerStats result = apiInstance.update(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DrachenPlayerStatsFacadeApi#update");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**DrachenPlayerStats**](DrachenPlayerStats.md)|  |

### Return type

[**DrachenPlayerStats**](DrachenPlayerStats.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

