# BackendConfigFacadeApi

All URIs are relative to *http://localhost:2020/*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create3**](BackendConfigFacadeApi.md#create3) | **POST** /config/create | 
[**delete3**](BackendConfigFacadeApi.md#delete3) | **DELETE** /config/delete | 
[**get1**](BackendConfigFacadeApi.md#get1) | **GET** /config/get/{name} | 
[**update3**](BackendConfigFacadeApi.md#update3) | **PATCH** /config/update | 

<a name="create3"></a>
# **create3**
> BackendConfig create3(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendConfigFacadeApi;


BackendConfigFacadeApi apiInstance = new BackendConfigFacadeApi();
BackendConfig body = new BackendConfig(); // BackendConfig | 
try {
    BackendConfig result = apiInstance.create3(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendConfigFacadeApi#create3");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendConfig**](BackendConfig.md)|  |

### Return type

[**BackendConfig**](BackendConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

<a name="delete3"></a>
# **delete3**
> delete3(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendConfigFacadeApi;


BackendConfigFacadeApi apiInstance = new BackendConfigFacadeApi();
BackendConfig body = new BackendConfig(); // BackendConfig | 
try {
    apiInstance.delete3(body);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendConfigFacadeApi#delete3");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendConfig**](BackendConfig.md)|  |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: Not defined

<a name="get1"></a>
# **get1**
> BackendConfig get1(name)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendConfigFacadeApi;


BackendConfigFacadeApi apiInstance = new BackendConfigFacadeApi();
String name = "name_example"; // String | 
try {
    BackendConfig result = apiInstance.get1(name);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendConfigFacadeApi#get1");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **name** | **String**|  |

### Return type

[**BackendConfig**](BackendConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: */*

<a name="update3"></a>
# **update3**
> BackendConfig update3(body)



### Example
```java
// Import classes:
//import me.drachenlord.api.client.invoker.ApiException;
//import me.drachenlord.api.client.api.BackendConfigFacadeApi;


BackendConfigFacadeApi apiInstance = new BackendConfigFacadeApi();
BackendConfig body = new BackendConfig(); // BackendConfig | 
try {
    BackendConfig result = apiInstance.update3(body);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling BackendConfigFacadeApi#update3");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**BackendConfig**](BackendConfig.md)|  |

### Return type

[**BackendConfig**](BackendConfig.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: */*

