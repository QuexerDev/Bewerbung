package me.drachenlord.system.drachenbackend.service;

import lombok.Getter;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayerStats;
import me.drachenlord.system.drachenbackend.repository.DrachenPlayerRepository;
import me.drachenlord.system.drachenbackend.repository.DrachenPlayerStatsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DrachenPlayerStatsService {

    @Autowired
    @Getter
    private DrachenPlayerStatsRepository drachenPlayerStatsRepository;

    public List<DrachenPlayerStats> getTop10(String mode) {
        return drachenPlayerStatsRepository.findTop10ByModeOrderByPointsDesc(mode);
    }

}
