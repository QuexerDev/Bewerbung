package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import me.drachenlord.system.drachenbackend.utils.JSONObjectConverter;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@Builder
public class DrachenPlayer extends BaseEntity{

    @Column(unique = true)
    private String uuid;

    private String name;

    @OneToOne(mappedBy = "drachenPlayer")
    private BackendChests chests;

    @OneToOne(mappedBy = "drachenPlayer")
    private BackendFriendSettings backendFriendSettings;

    @OneToOne(mappedBy = "drachenPlayer")
    private DrachenPlayerData drachenPlayerData;

    @OneToOne(mappedBy = "drachenPlayer")
    private DrachenPlayerDates drachenPlayerDates;

    @OneToMany(mappedBy = "punisher")
    private List<BackendBan> madeBans;

    private long banPoints;

    @ElementCollection
    private List<String> clientPerms;

    @Column(columnDefinition = "TEXT")
    @Convert(converter= JSONObjectConverter.class)
    private JSONObject data;

    private long groupId;

    private long groupExpire;


}
