package me.drachenlord.system.drachenbackend.entity;

public enum BanType {

    CHAT, BAN;

}
