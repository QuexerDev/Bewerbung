package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import me.drachenlord.system.drachenbackend.utils.JSONObjectConverter;
import org.json.JSONObject;

@Entity
@Data
@AllArgsConstructor
@Builder
public class DrachenPlayerStats extends BaseEntity {

    private String mode;
    private String uuid;

    private long points;

    @Column(columnDefinition = "TEXT")
    @Convert(converter= JSONObjectConverter.class)
    private JSONObject data;

}
