package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendFriend extends BaseEntity {


    private long senderId;

    private long targetId;

    private boolean accepted;

}
