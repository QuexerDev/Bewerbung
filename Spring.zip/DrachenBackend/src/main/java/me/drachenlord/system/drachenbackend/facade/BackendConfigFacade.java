package me.drachenlord.system.drachenbackend.facade;

import me.drachenlord.system.drachenbackend.entity.BackendConfig;
import me.drachenlord.system.drachenbackend.service.BackendConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("config")
public class BackendConfigFacade {

    @Autowired
    private BackendConfigService backendConfigService;

    @PostMapping("/create")
    public BackendConfig create(@RequestBody BackendConfig backendConfig) {
        return backendConfigService.getBackendConfigRepository().save(backendConfig);
    }

    @GetMapping("/get/{name}")
    public BackendConfig get(@PathVariable String name) {
        return backendConfigService.getBackendConfigRepository().findByName(name);
    }

    @PatchMapping("/update")
    public BackendConfig update(@RequestBody BackendConfig backendConfig) {
        return backendConfigService.getBackendConfigRepository().save(backendConfig);
    }

    @DeleteMapping("/delete")
    public void delete(@RequestBody BackendConfig backendConfig) {
        backendConfigService.getBackendConfigRepository().delete(backendConfig);
    }
}
