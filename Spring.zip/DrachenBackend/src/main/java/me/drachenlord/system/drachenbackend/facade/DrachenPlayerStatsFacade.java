package me.drachenlord.system.drachenbackend.facade;

import me.drachenlord.system.drachenbackend.entity.BackendGroup;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayerDates;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayerStats;
import me.drachenlord.system.drachenbackend.service.DrachenPlayerStatsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("stats")
public class DrachenPlayerStatsFacade {

    @Autowired
    private DrachenPlayerStatsService drachenPlayerStatsService;

    @PostMapping("/create")
    public DrachenPlayerStats create(@RequestBody DrachenPlayerStats drachenPlayerStats) {
        return drachenPlayerStatsService.getDrachenPlayerStatsRepository().save(drachenPlayerStats);
    }

    @GetMapping("/get/{uuid}/{mode}")
    public DrachenPlayerStats getByUuidAndMode(@PathVariable("uuid") String uuid, @PathVariable("mode") String mode) {
        return drachenPlayerStatsService.getDrachenPlayerStatsRepository().findByUuidAndMode(uuid, mode);
    }

    @GetMapping("/get/{uuid}")
    public List<DrachenPlayerStats> getAllByUuid(@PathVariable("uuid") String uuid) {
        return drachenPlayerStatsService.getDrachenPlayerStatsRepository().findAllByUuid(uuid);
    }

    @GetMapping("/getTop/{mode}")
    public List<DrachenPlayerStats> getTop10(@PathVariable("mode") String mode) {
        return drachenPlayerStatsService.getTop10(mode);
    }

    @PatchMapping("/update")
    public DrachenPlayerStats update(@RequestBody DrachenPlayerStats drachenPlayerStats) {
        return drachenPlayerStatsService.getDrachenPlayerStatsRepository().save(drachenPlayerStats);
    }

    @DeleteMapping("/delete")
    public void delete(@RequestBody DrachenPlayerStats drachenPlayerStats) {
        drachenPlayerStatsService.getDrachenPlayerStatsRepository().delete(drachenPlayerStats);
    }

}
