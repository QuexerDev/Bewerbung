package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.BackendFriend;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BackendFriendRepository extends CrudRepository<BackendFriend, Long> {

    //Get Friends
    List<BackendFriend> findAllByAcceptedIsTrueAndSenderIdOrTargetId(long senderId, long targetId);

    //Get Requests to self
    List<BackendFriend> findAllByAcceptedIsFalseAndTargetId(long targetId);

    //Get Requests sent
    List<BackendFriend> findAllByAcceptedIsFalseAndSenderId(long senderId);

}
