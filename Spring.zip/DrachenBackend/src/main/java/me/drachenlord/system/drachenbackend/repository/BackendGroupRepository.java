package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.BackendGroup;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BackendGroupRepository extends CrudRepository<BackendGroup, Long> {

    List<BackendGroup> findAllByIdNotNull();

}
