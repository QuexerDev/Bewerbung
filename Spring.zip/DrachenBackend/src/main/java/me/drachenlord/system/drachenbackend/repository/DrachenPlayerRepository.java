package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.DrachenPlayer;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayerDates;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DrachenPlayerRepository extends CrudRepository<DrachenPlayer, Long> {

    //Get all with that group
    List<DrachenPlayer> findAllByGroupId(long groupId);

    DrachenPlayer findByUuid(String uuid);

}
