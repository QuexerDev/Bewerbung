package me.drachenlord.system.drachenbackend.entity;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import javax.persistence.Entity;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendBan extends BaseEntity {

    private String uuid;

    private String punisher;

    private BanType banType;
    private String reason;
    private boolean active;
    private long punishedAt;
    private long punishEnd;


}
