package me.drachenlord.system.drachenbackend.facade;

import org.json.JSONObject;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;

@RestController
@RequestMapping("test")
public class TestFacade {

    @GetMapping("getTest/{msg}")
    public String getTest(@PathVariable String msg) {
        JSONObject object = new JSONObject();
        object.append("Message", msg)
                .append("Time", new SimpleDateFormat("dd/MM/yyyy").format(new Date()))
                .append("Status", 200);

        return object.toString();
    }


}
