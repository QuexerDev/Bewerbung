package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.BackendBan;
import me.drachenlord.system.drachenbackend.entity.BanType;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BackendBanRepository extends CrudRepository<BackendBan, Long> {

    //Get First Active Bans (In best case just one)
    BackendBan findByUuidAndActiveIsTrueAndBanType(String uuid, BanType banType);

    //Get Ban history
    List<BackendBan> findAllByUuidAndActiveIsFalse(String uuid);

    //Get Bans Made by Player
    List<BackendBan> findAllByPunisher(String punisher);
}
