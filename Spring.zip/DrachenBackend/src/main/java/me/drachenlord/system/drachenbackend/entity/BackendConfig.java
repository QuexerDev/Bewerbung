package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import me.drachenlord.system.drachenbackend.utils.JSONObjectConverter;
import org.json.JSONObject;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendConfig extends BaseEntity {

    @Column(unique = true)
    private String name;

    @Column(columnDefinition = "TEXT")
    @Convert(converter= JSONObjectConverter.class)
    private JSONObject data;

}
