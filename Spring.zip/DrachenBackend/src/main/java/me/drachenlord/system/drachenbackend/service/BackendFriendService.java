package me.drachenlord.system.drachenbackend.service;

import lombok.Getter;
import me.drachenlord.system.drachenbackend.entity.BackendFriend;
import me.drachenlord.system.drachenbackend.repository.BackendFriendRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BackendFriendService {

    @Autowired
    @Getter
    private BackendFriendRepository backendFriendRepository;

    public List<BackendFriend> getFriends(long id) {
        return backendFriendRepository.findAllByAcceptedIsTrueAndSenderIdOrTargetId(id, id);
    }

    public List<BackendFriend> getRequestsSent(long id) {
        return backendFriendRepository.findAllByAcceptedIsFalseAndSenderId(id);
    }

    public List<BackendFriend> getRequestsGot(long id) {
        return backendFriendRepository.findAllByAcceptedIsFalseAndTargetId(id);
    }
}
