package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@Builder
public class DrachenPlayerData extends BaseEntity {

    @OneToOne
    private DrachenPlayer drachenPlayer;

    private long mett;
    private long ofenkaese;

    private long level;
    private long xp;

}
