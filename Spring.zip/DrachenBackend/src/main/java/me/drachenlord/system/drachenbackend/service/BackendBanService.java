package me.drachenlord.system.drachenbackend.service;

import lombok.Getter;
import me.drachenlord.system.drachenbackend.entity.BackendBan;
import me.drachenlord.system.drachenbackend.entity.BanType;
import me.drachenlord.system.drachenbackend.repository.BackendBanRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BackendBanService {

    @Autowired
    @Getter
    private BackendBanRepository backendBanRepository;

    public BackendBan getActiveBan(String uuid) {
        return backendBanRepository.findByUuidAndActiveIsTrueAndBanType(uuid, BanType.BAN);
    }

    public BackendBan getActiveMute(String uuid) {
        return backendBanRepository.findByUuidAndActiveIsTrueAndBanType(uuid, BanType.CHAT);
    }

    public List<BackendBan> getBanHistory(String uuid) {
        return backendBanRepository.findAllByUuidAndActiveIsFalse(uuid);
    }

    public List<BackendBan> getMadeBans(String uuid) {
        return backendBanRepository.findAllByPunisher(uuid);
    }


}
