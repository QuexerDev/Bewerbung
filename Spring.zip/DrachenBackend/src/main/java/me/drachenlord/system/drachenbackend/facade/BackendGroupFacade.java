package me.drachenlord.system.drachenbackend.facade;

import me.drachenlord.system.drachenbackend.entity.BackendConfig;
import me.drachenlord.system.drachenbackend.entity.BackendGroup;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayer;
import me.drachenlord.system.drachenbackend.service.BackendGroupService;
import me.drachenlord.system.drachenbackend.service.DrachenPlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("group")
public class BackendGroupFacade {

    @Autowired
    private BackendGroupService backendGroupService;

    @Autowired
    private DrachenPlayerService drachenPlayerService;

    @PostMapping("/create")
    public BackendGroup create(@RequestBody BackendGroup backendGroup) {
        return backendGroupService.getBackendGroupRepository().save(backendGroup);
    }

    @GetMapping("/getPlayersInGroup/{id}")
    public List<DrachenPlayer> getAllById(@PathVariable("id") long id) {
        return drachenPlayerService.getDrachenPlayerRepository().findAllByGroupId(id);
    }

    @GetMapping("/getAll")
    public List<BackendGroup> getAll() {
        return backendGroupService.getBackendGroupRepository().findAllByIdNotNull();
    }

    @PatchMapping("/update")
    public BackendGroup update(@RequestBody BackendGroup backendGroup) {
        return backendGroupService.getBackendGroupRepository().save(backendGroup);
    }

    @DeleteMapping("/delete")
    public void delete(@RequestBody BackendGroup backendGroup) {
        backendGroupService.getBackendGroupRepository().delete(backendGroup);
    }

}
