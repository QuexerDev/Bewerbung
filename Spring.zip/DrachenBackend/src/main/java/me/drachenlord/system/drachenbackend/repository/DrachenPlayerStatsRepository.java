package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.DrachenPlayerStats;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface DrachenPlayerStatsRepository extends CrudRepository<DrachenPlayerStats, Long> {

    List<DrachenPlayerStats> findTop10ByModeOrderByPointsDesc(String mode);

    List<DrachenPlayerStats> findAllByUuid(String uuid);

    DrachenPlayerStats findByUuidAndMode(String uuid, String mode);

}
