package me.drachenlord.system.drachenbackend.service;

import lombok.Getter;
import me.drachenlord.system.drachenbackend.repository.DrachenPlayerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class DrachenPlayerService {

    @Autowired
    @Getter
    private DrachenPlayerRepository drachenPlayerRepository;

}
