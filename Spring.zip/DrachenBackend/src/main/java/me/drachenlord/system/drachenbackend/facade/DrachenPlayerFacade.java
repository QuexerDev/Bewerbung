package me.drachenlord.system.drachenbackend.facade;

import me.drachenlord.system.drachenbackend.entity.BackendConfig;
import me.drachenlord.system.drachenbackend.entity.DrachenPlayer;
import me.drachenlord.system.drachenbackend.service.BackendConfigService;
import me.drachenlord.system.drachenbackend.service.DrachenPlayerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("player")
public class DrachenPlayerFacade {

    @Autowired
    private DrachenPlayerService drachenPlayerService;

    @PostMapping("/create")
    public DrachenPlayer create(@RequestBody DrachenPlayer drachenPlayer) {
        return drachenPlayerService.getDrachenPlayerRepository().save(drachenPlayer);
    }

    @GetMapping("/get/{uuid}")
    public DrachenPlayer get(@PathVariable String uuid) {
        return drachenPlayerService.getDrachenPlayerRepository().findByUuid(uuid);
    }

    @PatchMapping("/update")
    public DrachenPlayer update(@RequestBody DrachenPlayer drachenPlayer) {
        return drachenPlayerService.getDrachenPlayerRepository().save(drachenPlayer);
    }

    @DeleteMapping("/delete")
    public void delete(@RequestBody DrachenPlayer drachenPlayer) {
        drachenPlayerService.getDrachenPlayerRepository().delete(drachenPlayer);
    }

}
