package me.drachenlord.system.drachenbackend.entity;


import javax.persistence.Entity;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendFriendSettings extends BaseEntity {

    @OneToOne
    private DrachenPlayer drachenPlayer;

    private boolean msg;
    private boolean request;
    private boolean party;
    private boolean jump;

}
