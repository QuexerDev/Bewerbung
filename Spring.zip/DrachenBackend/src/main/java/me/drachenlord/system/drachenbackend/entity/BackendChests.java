package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendChests extends BaseEntity{

    private int common;
    private int uncommon;
    private int rare;
    private int epic;
    private int legendary;

    @OneToOne
    private DrachenPlayer drachenPlayer;

}
