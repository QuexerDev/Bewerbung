package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Entity
@Data
@AllArgsConstructor
@Builder
public class BackendGroup extends BaseEntity {

    private String color;
    private String prefix;

    @ManyToMany
    @JoinTable(name = "GROUP_INHERITS",
    joinColumns = @JoinColumn(name = "group_id"),
    inverseJoinColumns = @JoinColumn(name = "igroup_id"))
    private List<BackendGroup> inherits;

    @ElementCollection
    private List<String> perms;

    private String fullName;
}
