package me.drachenlord.system.drachenbackend.repository;

import me.drachenlord.system.drachenbackend.entity.BackendConfig;
import org.springframework.data.repository.CrudRepository;

public interface BackendConfigRepository extends CrudRepository<BackendConfig, Long> {

    BackendConfig findByName(String name);


}
