package me.drachenlord.system.drachenbackend.entity;

import javax.persistence.Entity;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Entity
@Data
@AllArgsConstructor
@Builder
public class DrachenPlayerDates extends BaseEntity {

    @OneToOne
    private DrachenPlayer drachenPlayer;

    private long firstJoined;
    private long lastQuit;
    private long playTime;
    private long lastJoin;

}
