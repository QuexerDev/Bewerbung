package me.drachenlord.system.drachenbackend.facade;

import me.drachenlord.system.drachenbackend.entity.BackendBan;
import me.drachenlord.system.drachenbackend.service.BackendBanService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("ban")
public class BackendBanFacade {

    @Autowired
    private BackendBanService backendBanService;

    @PostMapping("/create")
    public BackendBan create(@RequestBody BackendBan backendBan) {
        return backendBanService.getBackendBanRepository().save(backendBan);
    }

    @GetMapping("/getActiveBan/{uuid}")
    public BackendBan getActiveBan(@PathVariable String uuid) {
        return backendBanService.getActiveBan(uuid);
    }

    @GetMapping("/getActiveMute/{uuid}")
    public BackendBan getActiveMute(@PathVariable String uuid) {
        return backendBanService.getActiveMute(uuid);
    }

    @GetMapping("/getBanHistory/{uuid}")
    public List<BackendBan> getBanHistory(@PathVariable String uuid) {
        return backendBanService.getBanHistory(uuid);
    }

    @GetMapping("/getMadeBans/{uuid}")
    public List<BackendBan> getMadeBans(@PathVariable String uuid) {
        return backendBanService.getMadeBans(uuid);
    }

    @PatchMapping("/update/{id}")
    public BackendBan updateBan(@PathVariable int id, @RequestBody BackendBan backendBan) {
        return backendBanService.getBackendBanRepository().save(backendBan);
    }

    @DeleteMapping("/delete")
    public void deleteBan(@RequestBody BackendBan backendBan) {
        backendBanService.getBackendBanRepository().delete(backendBan);
    }

}
