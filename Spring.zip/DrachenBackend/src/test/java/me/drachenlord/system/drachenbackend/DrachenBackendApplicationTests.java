package me.drachenlord.system.drachenbackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DrachenBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
